#pragma once

// VC++ has a tradition of using commas instead of dots here.

#define $projectsymbol$_FILE_VERSION_NUMBER $projectversion$
#define $projectsymbol$_PROD_VERSION_NUMBER $projectversion$
#define $projectsymbol$_FILE_VERSION_TEXT "$projectversion$"
#define $projectsymbol$_PROD_VERSION_TEXT "$projectversion$"
#define $projectsymbol$_COPYRIGHT_TEXT "Copyright $year$ Esselle Jaye - MIT/Expat license"
#define DD_COMPANY_TEXT  "DigitalDreamers.org - Esselle Jaye"